#PDO MySQL Login

Very Simple PHP Login &amp; Register using PDO MySQL

![pdo](https://cloud.githubusercontent.com/assets/13184472/15992457/d6f7c5dc-30ee-11e6-844c-958712281490.png)

Here, I'm trying to include full login, registration, forgot password system. It's the basic PDO MySQl code. You can make any kind of login, registration system by this code.

Output Demo: https://youtu.be/SgZNYrz9AWE
